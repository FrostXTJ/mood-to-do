# MoodToDo
 This is USC CSCI201 Software Development final project.
 It currently only includes an index page with well-looking GUI.
 * The gcp credential has been removed for security reason, and I think we will work on Heather's database after she finished her codes.
