package TMDB;

import java.util.ArrayList;

import general.Entry;

public class Movie extends Entry {
	
	private ArrayList<String> genres;
	private String releaseDate;
	float rating;
	String other;

	
	@SuppressWarnings("unchecked")
	public Movie(String name, String thumbnailPath, String description, 
			ArrayList<String> genres, String releaseDate ,float rating, String id, String other) {
		super(name, thumbnailPath, description, id);
		this.genres = (ArrayList<String>)genres.clone();
		this.releaseDate = releaseDate;
		this.rating = rating;
		this.other = other;
	
	}
	
	public ArrayList<String> getGenres() {
		return this.genres;
	}
	
	public String getReleaseDate() {
		releaseDate = this.releaseDate;
		releaseDate = releaseDate.replaceAll("\"", " ");
		return releaseDate;
	}
	
	public float getRating() {
		return this.rating;
	}
	
	public String getOther() {
		return this.other;
	}
	

}
